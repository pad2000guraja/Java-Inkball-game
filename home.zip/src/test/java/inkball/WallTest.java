package inkball;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import processing.core.PImage;

import static org.junit.jupiter.api.Assertions.*;

public class WallTest {

    private Wall wall;
    private PImage imageMock;

    @BeforeEach
    public void setUp() {
        imageMock = new PImage();
        wall = new Wall(100, 150, imageMock);
    }

    @Test
    public void testGetX() {
        assertEquals(100, wall.getX());
    }

    @Test
    public void testGetY() {
        assertEquals(150, wall.getY());
    }
}
