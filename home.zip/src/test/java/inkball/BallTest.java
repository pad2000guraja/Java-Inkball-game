package inkball;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class BallTest extends PApplet {
    private Ball ball;
    private App game;
    private PImage dummyImage;

    @BeforeEach
    public void setUp() {
        game = new App();
        dummyImage = createDummyImage();
        ball = new Ball(100, 100, dummyImage, "grey", game);
    }

    private PImage createDummyImage() {
        PImage img = new PImage(32, 32);
        img.loadPixels();
        for (int i = 0; i < img.pixels.length; i++) {
            img.pixels[i] = 0xFFFFFFFF;
        }
        img.updatePixels();
        return img;
    }

    @Test
    public void testInitialPosition() {
        assertEquals(100, ball.getX(), "Initial X position should be 100.");
        assertEquals(100, ball.getY(), "Initial Y position should be 100.");
    }

    @Test
    public void testSetPosition() {
        ball.setPosition(150, 150);
        assertEquals(150, ball.getX(), "X position should be updated to 150.");
        assertEquals(150, ball.getY(), "Y position should be updated to 150.");
    }

    @Test
    public void testBallMovementWithoutCollisions() {
        ArrayList<Wall> walls = new ArrayList<>();
        ArrayList<ArrayList<int[]>> lines = new ArrayList<>();
        ArrayList<Hole> holes = new ArrayList<>();

        ball.update(walls, lines, holes, 64, 576, 640);
        assertTrue(ball.getX() > 100 || ball.getY() > 100, "Ball should move if no collisions occur.");
    }

    @Test
    public void testWallCollision() {
        Wall wall = new Wall(120, 100, dummyImage);
        ArrayList<Wall> walls = new ArrayList<>();
        walls.add(wall);

        ball.setPosition(120, 100);
        ball.update(walls, new ArrayList<>(), new ArrayList<>(), 64, 576, 640);

        assertEquals(2, ball.vx, "Ball should have reversed horizontal velocity due to wall collision.");
    }

    @Test
    public void testHoleAttraction() {
        Hole hole = new Hole(100, 100, dummyImage, "grey");
        ArrayList<Hole> holes = new ArrayList<>();
        holes.add(hole);

        ball.update(new ArrayList<>(), new ArrayList<>(), holes, 64, 576, 640);

        assertTrue(ball.vx > 0 || ball.vy > 0, "Ball should have velocity towards the hole due to attraction.");
    }

    @Test
    public void testCaptureBall() {
        Hole hole = new Hole(100, 100, dummyImage, "grey");
        ArrayList<Hole> holes = new ArrayList<>();
        holes.add(hole);

        ball.setPosition(100, 100);
        ball.update(new ArrayList<>(), new ArrayList<>(), holes, 64, 576, 640);

        assertTrue(ball.isCaptured, "Ball should be captured when in the hole.");
    }

    @Test
    public void testReflectBall() {
        ArrayList<ArrayList<int[]>> lines = new ArrayList<>();
        ArrayList<int[]> line = new ArrayList<>();
        line.add(new int[]{50, 50});
        line.add(new int[]{150, 50});
        lines.add(line);

        ball.setPosition(100, 45);
        ball.update(new ArrayList<>(), lines, new ArrayList<>(), 64, 576, 640);

        assertEquals(2, ball.vx, "Ball's velocity should be reversed after reflecting off the line.");
    }
}
