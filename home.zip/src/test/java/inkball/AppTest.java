package inkball;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;

class AppTest {
    private App app;

    @BeforeEach
    void setUp() {
        app = new App();
        app.configPath = "config.json";
        app.setup();
    }

    @Test
    void testIncreaseScore() {
        int initialScore = app.score;
        app.increaseScore("grey");
        int scoreAfterIncrease = app.score;

        float expectedIncrease = app.scoreIncreaseBase.getInt("grey") * app.scoreIncreaseModifier;
        assertEquals(initialScore + expectedIncrease, scoreAfterIncrease);
    }

    @Test
    void testDecreaseScore() {
        app.score = 100;
        app.decreaseScore("grey");
        int scoreAfterDecrease = app.score;

        float expectedDecrease = app.scoreDecreaseBase.getInt("grey") * app.scoreDecreaseModifier;
        assertEquals(100 - expectedDecrease, scoreAfterDecrease);
    }

    @Test
    void testSpawnNextBall() {
        app.unspawnedBalls.add(new Ball(0, 0, new PImage(), "grey", app));
        int initialBallCount = app.balls.size();

        app.spawnNextBall();

        assertEquals(initialBallCount + 1, app.balls.size());
    }

    @Test
    void testLoadLevel() {
        JSONArray levels = app.config.getJSONArray("levels");
        assertTrue(levels.size() > 0, "No levels found in the config file.");

        JSONObject levelConfig = levels.getJSONObject(0);
        app.loadLevel(levelConfig);

        assertFalse(app.walls.isEmpty(), "Walls should be loaded from level.");
        assertFalse(app.holes.isEmpty(), "Holes should be loaded from level.");
    }

    @Test
    void testPauseFunctionality() {
        assertFalse(app.paused, "Game should start unpaused.");
        app.keyPressed();
        assertTrue(app.paused, "Game should be paused after pressing space.");
        app.keyPressed();
        assertFalse(app.paused, "Game should be unpaused after pressing space again.");
    }

    @Test
    void testDisplayLossMessage() {
        app.frameCount = app.levelTime * 50;
        app.displayLossMessage();
    }
    @Test
    void testDrawPausedScreen() {
        app.frameCount = app.levelTime * 30;
        app.drawPausedScreen();
    }
}
