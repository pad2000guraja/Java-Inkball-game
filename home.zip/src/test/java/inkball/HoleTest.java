package inkball;

import processing.core.PImage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HoleTest {
    private Hole hole;
    private PImage imageMock;

    @BeforeEach
    public void setUp() {
        imageMock = new PImage();
        hole = new Hole(100, 100, imageMock, "orange_hole");
    }

    @Test
    public void testGetColor() {
        assertEquals("orange_hole", hole.getColor(), "Hole color should be orange");
    }

    @Test
    public void testGetCenterX() {
        assertEquals(132, hole.getCenterX(), 0.01, "Center X should be 132");
    }

    @Test
    public void testGetCenterY() {
        assertEquals(132, hole.getCenterY(), 0.01, "Center Y should be 132");
    }
}

